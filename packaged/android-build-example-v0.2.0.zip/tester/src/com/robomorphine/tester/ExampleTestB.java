package com.robomorphine.tester;

import junit.framework.TestCase;

public class ExampleTestB extends TestCase {
    
    public void testA() {
        
    }
    
    public void testB() {
        
    }
    
    public void testC() {
        
    }
    
    public void testD() {
        
    }
}
